import React from "react";
import '../assets/styles/main.css';

const Table = () =>{
    return(
        <>
            <h1>Hello External CSS</h1>
        </>
    )
}

export default Table