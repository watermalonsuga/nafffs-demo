import React from "react";

const Form = () =>{
    return(
        <>
            <form>
                <label>Name</label>
                <input type="text" name="name" placeholder="Enter Your Name"></input><br></br>

                <label>Mobile </label>
                <input type="number" name="mobile" placeholder="Enter Mobile"></input><br></br>

                <label>Email Id</label>
                <input type="email" name="email" placeholder="Enter Email Id"></input><br></br>

                <label>Date of Birth</label>
                <input type="date" name="dob"></input><br></br>

                <label>Gender</label>
                <input type="radio" name="gender" value={'male'}></input> Male
                <input type="radio" name="gender" value={'female'}></input> Female
                <input type="radio" name="gender" value={'other'}></input> Other <br></br>

                <label>Religion</label>
                <select name="religion">
                    <option disabled selected value={''}>--Select Religion--</option>
                    <option value={'hindu'}>Hindu</option>
                    <option value={'islam'}>Islam</option>
                    <option value={'sikh'}>Sikh</option>
                    <option value={'other'}>Other</option>
                </select><br></br>

                <label>Image</label>
                <input type="file" name="image"></input><br></br>

                <label>Message</label>
                <textarea></textarea><br></br>

                <label>Password</label>
                <input type="password" name="pass"></input><br></br>

                <button type="submit">Submit</button>
            </form>
        </>
    )
}

export default Form