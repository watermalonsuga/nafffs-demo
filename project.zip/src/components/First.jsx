import React from "react";
import Img from '../assets/images/img.jpg';

let value = "Hello Reactjs Component";

const cssStyle = {
    color:'red'
}

const First = () =>{
    return(
        <>
            <h1 style={cssStyle}>{value}</h1>
        </>
    )
}

export default First;