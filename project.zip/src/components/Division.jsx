import React from "react";
import '../assets/styles/main.css';
import Shishir from '../assets/images/shishir.webp';

const Division = () =>{
    return(
        <>
            <div className="whole-card">
                <div className="card">
                    <div className="img">
                        <img src={Shishir} alt={Shishir} height={'120px'} width={'120px'}></img>
                    </div>
                    <h4>Prof. Shishir Sinha</h4>
                    <div className="desi">
                        <p>Chairman, ACMS 2026</p>
                    </div>
                    <div className="desc">
                        <p>
                            Director General Central Institute of Petrochemicals Engineering & Technology
                        </p>
                    </div>
                </div>
                <div className="card">
                     <div className="img">
                        <img src={Shishir} alt={Shishir} height={'120px'} width={'120px'}></img>
                    </div>
                    <h4>Prof. Shishir Sinha</h4>
                    <div className="desi">
                        <p>Chairman, ACMS 2026</p>
                    </div>
                    <div className="desc">
                        <p>
                            Director General Central Institute of Petrochemicals Engineering & Technology
                        </p>
                    </div>
                </div>
                <div className="card">
                     <div className="img">
                        <img src={Shishir} alt={Shishir} height={'120px'} width={'120px'}></img>
                    </div>
                    <h4>Prof. Shishir Sinha</h4>
                    <div className="desi">
                        <p>Chairman, ACMS 2026</p>
                    </div>
                    <div className="desc">
                        <p>
                            Director General Central Institute of Petrochemicals Engineering & Technology
                        </p>
                    </div>
                </div>
                <div className="card">
                     <div className="img">
                        <img src={Shishir} alt={Shishir} height={'120px'} width={'120px'}></img>
                    </div>
                    <h4>Prof. Shishir Sinha</h4>
                    <div className="desi">
                        <p>Chairman, ACMS 2026</p>
                    </div>
                    <div className="desc">
                        <p>
                            Director General Central Institute of Petrochemicals Engineering & Technology
                        </p>
                    </div>
                </div>
                <div className="card">
                     <div className="img">
                        <img src={Shishir} alt={Shishir} height={'120px'} width={'120px'}></img>
                    </div>
                    <h4>Prof. Shishir Sinha</h4>
                    <div className="desi">
                        <p>Chairman, ACMS 2026</p>
                    </div>
                    <div className="desc">
                        <p>
                            Director General Central Institute of Petrochemicals Engineering & Technology
                        </p>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Division